const fname = document.getElementById('fname')
const lname = document.getElementById('lname')
const username = document.getElementById('username')
const email = document.getElementById('email')
const password = document.getElementById('password')
const cpassword = document.getElementById('cpassword')
const errorElement = document.getElementById('error')
const validation = document.getElementById('validation')

validation.addEventListener('signup', (e) =>{
    let messages = []
    if(fname.value === '' || fname.value == null){
        messages.push('First Name is Required')
    }
    if(password.length > 6){
        messages.push('Password not strong enough')
    }
    if(messages.length > 0){
        e.preventDefault()
        errorElement.innerText = messages.join(', ')

    }
})